# SwagFacebook

## A Facebook integration for shopware

## License

The MIT License (MIT). Please see [License File](LICENSE.md) for more information.
